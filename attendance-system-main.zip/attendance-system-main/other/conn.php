<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "attendancesystemapp001";

    date_default_timezone_set('Africa/Nairobi');
?>
