ATTENDANCE.APP V 1.01

----------------------
GENERAL INSTRUCTIONS
---------------------

1.0 GETTING STARTED 

- Copy/upload the folder containing this app and its dependancies (attendance.app) to the root folder of your server.
    -> If you're using xammp this will be the htdocs folder.

- Restart Apache server.
- Go to your domain/home.php to access the app.
    -> If you're using xammp this will be 127.0.0.1/home.php    

1.1 FIRST TIME LOG IN 

- If you'er logging in for the first time then you have to go to signup (click on signup button besides the login button).
- You'll be redirected to the signup page where you can enter the admin details and save. you can now go back and log in.

- ALTERNATIVELY, you can use this username and password to log in and register a new admin after logging in. 
    NOTE THAT this will only work until you register an admin.
        Username : admin
        Password : admin

1.3 OTHER LOG IN's

- All other log ins will be normal, provide a registered username and password.
    NOTE THAT only admins can log into the system. Employees can only clock in and out.