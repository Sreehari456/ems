<?php

echo '<script>
        window.location.href="./other/login.php";
      </script>'

?>